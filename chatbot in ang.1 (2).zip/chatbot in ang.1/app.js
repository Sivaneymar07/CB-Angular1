
var ToyBox = angular.module('ToyBox',[
    'ngRoute',
    'ToyBox.router',
    'ui.bootstrap',
    'ToyBox.homeController',
    'ToyBox.gotoController',
    'ToyBox.toyboxController',
    'ToyBox.libraryController',
    'ToyBox.prototypeController',
    'ToyBox.customerDataController',
    'ToyBox.repoController',
    'ToyBox.micrositeController',
    'ToyBox.libraryFactory',
    'ToyBox.readyPageController'
]);


app.directive('backButton', function() {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            element.bind('click', goBack);

            function goBack() {
                history.back();
                scope.$apply();
            }
        }
    }
});

app.directive('tempSection', function() {
    return {
        restrict: 'E',
        link: function(scope, element, attrs) {
            scope.getContentUrl = function() {
                return 'template/' + attrs.ver + '.html';
            }
        },
        templateUrl: 'template/micrositeTemp.html',
        controller: 'micrositeController',
        scope: {
            save: '&',
            plus: '&',
            disableEditor: '&',
            chooseTemplate: '&',
            titleName: '='
        }
    }
});
app.service('themeService',function(){

})
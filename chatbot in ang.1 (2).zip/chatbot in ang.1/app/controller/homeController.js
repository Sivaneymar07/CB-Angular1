
angular.module('ToyBox.homeController',[])
    .controller("homeController",homeController);

 	function homeController($scope,$location){
 		$scope.gotoRepo = function(){
 			$location.path('/library'); 
 		}	
		$scope.gotoConcept = function(){
 			$location.path('/conceptBuilder'); 
 		}
		 $scope.gotoService = function(){
 			$location.path('/servicerequest_home'); 
 		}		
	}	

 	homeController.$inject = ['$scope','$location'];

	
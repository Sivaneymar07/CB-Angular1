var app = angular.module('ToyBox.libraryController', [])
    .controller("libraryController", libraryController);


// $rootScope.chat_height = $('.panel-body').outerHeight();




function libraryController($scope, $location, libraryFactory) {
    $scope.displayFilterDetails = false;
    $scope.displaySortDetails = false;
    $scope.searchshowable = false;
    $scope.sortValue = "select";
    $scope.FilterList = [];


    // code for calling getLibraryData() for getting libraryList
    libraryFactory.getLibraryData()
        .then(function(response) {
                $scope.libraryList = response.data;
            },
            function(error) {

            });
    $scope.setValues = function() {
        $scope.showable = false;
        console.log('asdasdasd')
    }
    $scope.getTitleFromLibrary = function(book){
    console.log(book);
    return book.match(($scope.userQueryTitle).split(" ")[0]) || 
        book.match(($scope.userQueryTitle).split(" ")[1]);
};


    //code for search show
    $scope.searchshow = function() {
        $scope.searchshowable = !$scope.searchshowable;
    }



    // ng-click function definition

    $scope.gotoPrototypeDetail = function(library) {
        $location.path('/prototype');
        libraryFactory.setLibrary(library);
    }

    $scope.displayFilterList = function() {
        $scope.displaySortDetails = false;
        $scope.displayFilterDetails = !($scope.displayFilterDetails);
        $scope.showable = true;
    }

    $scope.displaySortList = function() {
        $scope.displayFilterDetails = false;
        $scope.displaySortDetails = !($scope.displaySortDetails);
        $scope.showable = true;
    }

    $scope.addToFilterList = function(FilterValue, checked) {
        if (checked) {
            var index = $scope.FilterList.indexOf(FilterValue);
            if (index === -1) {
                $scope.FilterList.push(FilterValue);
            }
        } else {
            var index = $scope.FilterList.indexOf(FilterValue);
            if (index > -1) {
                $scope.FilterList.splice(index, 1);
            }
        }
        console.log($scope.FilterList);
    }


}
libraryController.$inject = ['$scope', '$location', 'libraryFactory'];
// controller ends here


app.filter('firstWord',function(){
    
    return function(value, wordwise, max, tail){
        console.log(value.length);
         if (value.length > 0) {
                for (i = 0; i < value.length; i++) {
                    if(value[i].title.indexOf(' ')>=0){
                    data = value[i].title.split(' ')
                    a = data[0] +' '+ data[1];
                     value[i].title = a;               
                     } 
                }
            }
            
            
           
          
        return value;
    
       
}
})


// code for search using libraryName, category and domain
app.filter('customFilter', function() {
    return function(libraryList, searchValues) {
        var temp;
        if (angular.isDefined(searchValues)) {
            var results = [];
            var i;
            var searchVal = searchValues.toLowerCase();
            if (libraryList.length > 0) {
                for (i = 0; i < libraryList.length; i++) {
                    var libraryTitle = libraryList[i].title.toLowerCase();
                    // var category = libraryList[i].category.toLowerCase();
                    // var domain = libraryList[i].domain.toLowerCase();
                    //if(libraryTitle.indexOf(searchVal) >= 0 || category.indexOf(searchVal) >= 0 || domain.indexOf(searchVal) >= 0){
                    if (libraryTitle.indexOf(searchVal) >= 0) {
                        results.push(libraryList[i]);
                    }
                }
            }
            temp = results;
        } else {
            temp = libraryList;
        }

        return temp;
    };
});



// code for search using filterList
app.filter('customFilterList', function() {
    return function(libraryList, filterList) {
        var temp;
        if (filterList.length > 0) {
            temp = [];
            var results = [];
            var i, j;
            for (j = 0; j < filterList.length; j++) {
                for (i = 0; i < libraryList.length; i++) {
                    var category = libraryList[i].category.toLowerCase();
                    var domain = libraryList[i].domain.toLowerCase();
                    if (category.indexOf(filterList[j]) >= 0 || domain.indexOf(filterList[j]) >= 0) {
                        results.push(libraryList[i]);
                    }
                }
            }
            temp = results;
        } else {

            temp = libraryList;
        }
        temp = removeDuplicates(temp, "libraryName");
        return temp;
    };
});

// code for sorting filter
app.filter('sortFilter', function() {
    return function(libraryList, sortValue) {
        var temp;
        if (sortValue.length > 0 && sortValue !== "select") {

            if (sortValue === "libraryName") {

                libraryList.sort(function(a, b) {

                    var nameA = a.libraryName.toLowerCase();
                    var nameB = b.libraryName.toLowerCase();
                    if (nameA < nameB)
                        return -1
                    if (nameA > nameB)
                        return 1
                    return 0
                });

            } else if (sortValue === "rating") {

                libraryList.sort(function(a, b) {
                    return -(a.rating - b.rating);
                });
            } else if (sortValue === "popularity") {

                libraryList.sort(function(a, b) {
                    return -(a.popularity - b.popularity);
                });
            }

            temp = libraryList;

        } else {

            temp = libraryList;
        }
        return temp;
    };
});


app.directive('messageItem', function(chat, $compile) {
    return {
        restrict: "E",
        link: function(scope, element, attributes) {
            // var chat_height = $('.panel-body').outerHeight();

            // $('.panel-body').animate({ scrollTop: $(document).height() }, 1000); 
        },
        controller: function($scope, $element, $rootScope) {

            $rootScope.$on('userMessage', function(e, data) {
                //console.log("event emitted " + data.usermessage);
                $scope.msg = data.usermessage;
                var el = $compile('<p class="user-msg me">' + $scope.msg + '</p>')($scope);
                $element.parent().append(el);
            });
            $rootScope.$on('serverMessage', function(e, data) {
                //console.log("event emitted " + data.servermessage);
                $scope.sMsg = data.servermessage;
                var el = $compile('<span class="user-msg you">' + $scope.sMsg + '</span>')($scope);
                $element.parent().append(el);
                var chat_height = $('.panel-body').outerHeight();;
                var chat_height = 10 * chat_height;
                //console.log(chat_height);
                $('.panel-body').scrollTop(chat_height);
            });
        }
    }
});


app.directive('chatForm', function() {
    return {
        templateUrl: 'template/chatForm.html',
        controller: function($scope, $rootScope, chat) {
            var flag = 1;
         
            $scope.message = "";
            $scope.sendMsg = function() {
                console.log($scope.message);
                if (flag == 1) {
                    var msg = "Hi, I am Amy from the ToyBox team . Toybox serves as the one stop shop to validate prototyping ideas and foster innovation. Would you be interested to know more?"
                    flag = 0;
                    setTimeout(function() {
                        $rootScope.$emit('serverMessage', {
                            servermessage: msg
                        });
                    }, 1000);
                }
                if ($scope.message) {
                    $rootScope.$emit('userMessage', {
                        usermessage: $scope.message
                    });
                    chat.postMessage($scope.message, function(data) {
                        var result = data.result;
                        var output = result.fulfillment.speech
                          
                        if (output.indexOf("compute") !== -1) {
                            a = output.split('/');
                            console.log(a);
                            tableReply = '<table class="table-bordered"><caption id="caption">This is Your User Credentials</caption>'
                                // setTimeout(function () {
                                //     console.log("delay of 2 seconds")
                                //    }, 2000);  
                            for (msg in a) {
                                tableFlag = 0;

                                // setTimeout(function () {
                                if (msg == 1) {
                                    reply = "Please use remote desktop software " + "<br>" + "<a target='_blank' id='link' href='https://www.teamviewer.com/en/download'><span>[https://www.teamviewer.com]</span></a>" + "<br>" + " to access the instance."
                                    $rootScope.$emit('serverMessage', {
                                        servermessage: reply
                                    });
                                }
                               
                                else if (msg == 2 || msg == 3 || msg == 4) {
                                    c = a[msg].split(':')
                                    console.log(c);
                                    console.log(tableReply);
                                    tableReply = tableReply + '<tr><td id="data"><strong>' + c[0] + '<strong></td>' + '<td id="data">' + c[1] + '</td></tr>';
                                    console.log(tableReply);
                                    if (msg == 4) {
                                        tableFlag = 1;
                                    }
                                    if (tableFlag == 1) {
                                        tableReply += '</table>'
                                        $rootScope.$emit('serverMessage', {
                                            servermessage: tableReply
                                        });
                                    }
                                } else
                                    $rootScope.$emit('serverMessage', {
                                        servermessage: a[msg]
                                    });
                                //  }, 2000);
                            }
                        }
                        // else if(output.indexOf("names")!==-1){
                        //     a = output + '<br>' + '<input type ="text">';
                        // }
                        else {
                            // j= output + '<a class="link" href="http://mean.io/">@ http://mean.io/.</a>';
                            console.log(result.fulfillment.speech);
                            $rootScope.$emit('serverMessage', {
                                servermessage: output
                            });

                        }
                    });
                }
                $scope.message = "";
            }
        }
    }
});
app.factory('chat', function($http, $log) {
    var chatSev = {};
    chatSev.postMessage = function(message, cb) {
        $http({
            url: '/msg',
            method: 'POST',
            data: {
                message: message
            }
        }).then(function(res) {
            cb(res.data);
        }, function(res) {
            $log.error("error");
        });
    }
    return chatSev;
});

// code for removing duplicates from object array
function removeDuplicates(arrayList, libraryName) {
    var obj = {};
    if (arrayList.length > 0) {
        for (var i = 0, len = arrayList.length; i < len; i++) {
            if (!obj[arrayList[i][libraryName]])
                obj[arrayList[i][libraryName]] = arrayList[i];
        }
    }
    var resultArray = [];
    for (var key in obj) resultArray.push(obj[key]);
    return resultArray;
}

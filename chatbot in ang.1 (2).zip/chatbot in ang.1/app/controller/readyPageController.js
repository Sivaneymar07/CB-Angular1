// readyPage controller
var app = angular.module('ToyBox.readyPageController',[])
.controller('readyPageController', function($scope, $rootScope, $location, $anchorScroll) {
    $scope.hostpage = function() {
        $rootScope.hostClicked = true;
        localStorage.setItem('hostClick', true);
    }
});
